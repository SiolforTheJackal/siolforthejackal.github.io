Merry Christmas Alice. 

WASD/Arrow Keys to move, Space to interact with signs and displays. 

The elves, when presenting this plan to me, overscoped a bit. What with preparing all the other presents in the
world I had to cut the section of the museum where I went over all your jam entries , but I hope you're happy with what remained. 
I've gotten the elves a mandatory course in how to estimate total work load to prevent this from happening next year. 
They've gone back to the rocks and hills to ponder over the lessons as me and my brothers deliver presents all around the world. 


From all of the elves here at the Arctic circle. 

Santa. 
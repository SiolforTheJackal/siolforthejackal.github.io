Here is a nice shiny new banner for Fire Hammer Audio!
Png file and PaintDotNet file provided so you can edit it if you wish!

Hope you like it, I'm not the best artist

Either why Here is a joke I think you'll get a kick out of!

;)